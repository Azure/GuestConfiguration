Write-Warning ' Loading this module '

enum ensure {
    Absent
    Present
}

class reason {
    [DscProperty()]
    [string] $code

    [DscProperty()]
    [string] $phrase
}

<#
   Functions
#>

function Get-DSCFile {
    param(
        [ensure]$ensure = 'Present',
        
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$path,

        [String]$content
    )
    $fileContent        = [reason]::new()
    $fileContent.code   = 'file:file:content'

    $filePresent        = [reason]::new()
    $filePresent.code   = 'file:file:path'

    $ensure = 'Absent'
    $Path =  $ExecutionContext.InvokeCommand.ExpandString($Path)  
    Write-Verbose "In get, the path is $path"
    Write-Debug "In get, the path is $path"
    $fileExists = Test-path $path -ErrorAction SilentlyContinue

    if ($true -eq $fileExists) {
        $filePresent.phrase     = "The file was expected to be: $ensure`nThe file exists at path: $path"
        
        $existingFileContent    = Get-Content $path -Raw
        if ($null -eq $existingFileContent) {
            $existingFileContent = ''
        }
        $fileContent.phrase     = "The file was expected to contain: $content`nThe file contained: $existingFileContent"

        if ($content -eq $existingFileContent) {
            $ensure = 'Present'
        }
    }
    else {
        $filePresent.phrase     = "The file was expected to be: $ensure`nThe file does not exist at path: $path"
    }

    return @{
        ensure  = $ensure
        path    = $path
        content = $existingFileContent
        reasons = @($filePresent,$fileContent)
    }
}

function Set-DSCFile {
    param(
        [ensure]$ensure = "Present",
        
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$path,

        [String]$content
    )
    $Path =  $ExecutionContext.InvokeCommand.ExpandString($Path)
    
    Write-Verbose "In set, the path is $path"
    Write-Debug "In set, the path is $path"
    Write-Verbose "In set, the ensure is $ensure"
    Write-Verbose "In set, the content is $content"
    
    # Remove-Item $path -Force -ErrorAction SilentlyContinue
    if ($ensure -eq "Present") {
        New-Item $path -ItemType File -Force
        $content | Set-Content $path -NoNewline -Force
    }
    else {
        Remove-Item $path -Force -ErrorAction Stop
    }
}

function Test-DSCFile {
    param(
        [ensure]$ensure = "Present",
        
        [parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]$path,

        [String]$content
    )
    $Path =  $ExecutionContext.InvokeCommand.ExpandString($Path)
    Write-Verbose "In test, the path is $path"
    Write-Debug "In test, the path is $path"
    $test = $false
    $get = Get-DSCFile @PSBoundParameters
    Write-Verbose "In test, the result from get is $get"
    foreach($k in $get.Keys){Write-Verbose "$k $($get[$k])"}

    
    if ($get.ensure -eq $ensure) {
        $test = $true
    }
    return $test
}

<#
   DSC Resource
#>

[DscResource()]
class MyFile {
    
    [DscProperty(Mandatory)]
    [ensure] $ensure

    [DscProperty(Key)]
    [string] $path

    [DscProperty()]
    [string] $content

    [DscProperty()]
    [reason[]] $reasons

    [MyFile] Get() {
        $get = Get-DSCFile -ensure $this.ensure -path $this.path -content $this.content
        return $get
    }
    
    [void] Set() {
        $set = Set-DSCFile -ensure $this.ensure -path $this.path -content $this.content
    }

    [bool] Test() {
        $test = Test-DSCFile -ensure $this.ensure -path $this.path -content $this.content
        return $test
    }
}
