enum Ensure
{
    Absent
    Present
}

class Reason
{
    [DscProperty()]
    [String] $Code

    [DscProperty()]
    [String] $Phrase
}

function Get-TestFile
{
    [CmdletBinding()]
    [OutputType([TestFile])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content,

        [Parameter()]
        [Ensure]
        $Ensure = [Ensure]::Present
    )

    Write-Verbose -Message "Starting Get on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content`n`tEnsure:$Ensure"

    $ensureResult = [Ensure]::Absent
    $testFileContent = $null
    $reasons = @()

    Write-Verbose -Message "Retrieving test file from the path '$Path'"
    $testFileExists = Test-Path -Path $Path

    if ($testFileExists)
    {
        $testFileContent = Get-Content -Path $Path -Raw

        if ($Ensure -eq [Ensure]::Absent)
        {
            $reason = [Reason]::new()
            $reason.Code   = 'TestFile:TestFile:FileExists'
            $reason.Phrase = "The file exists when it was not expected to at the path '$Path'"
            $reasons += $reason
        }

        if ($testFileContent -eq $Content)
        {
            $ensureResult = [Ensure]::Present
        }
        else
        {
            $reason = [Reason]::new()
            $reason.Code   = 'TestFile:TestFile:FileContentMismatch'
            $reason.Phrase = "The file content was expected to be: '$Content' but the actual file content is: '$testFileContent'"
            $reasons += $reason
        }
    }
    else
    {
        if ($Ensure -eq [Ensure]::Present)
        {
            $reason = [Reason]::new()
            $reason.Code   = 'TestFile:TestFile:FileNotExists'
            $reason.Phrase = "The file does not exist when it was expected to exist at the path '$Path'"
            $reasons += $reason
        }
    }

    $result = [TestFile]::new()
    $result.Path = $Path
    $result.Content = $testFileContent
    $result.Ensure = $ensureResult
    $result.Reasons = $reasons

    Write-Verbose -Message "Finished Get on TestFile"

    return $result
}

function Set-TestFile
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content,

        [Parameter()]
        [Ensure]
        $Ensure = [Ensure]::Present
    )

    Write-Verbose -Message "Starting Set on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content`n`tEnsure:$Ensure"

    # Remove-Item $path -Force -ErrorAction SilentlyContinue
    if ($Ensure -eq [Ensure]::Present)
    {
        $null = Set-Content -Path $Path -Value $Content -NoNewline -Force
    }
    elseif (Test-Path -Path $Path)
    {
        $null = Remove-Item -Path $Path -Force
    }

    Write-Verbose -Message "Finished Set on TestFile"
}

function Test-TestFile
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content,

        [Parameter()]
        [Ensure]
        $Ensure = [Ensure]::Present
    )

    Write-Verbose -Message "Starting Test on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content`n`tEnsure:$Ensure"

    $getTestFileResult = Get-TestFile @PSBoundParameters
    $testResult = $getTestFileResult.Ensure -eq $Ensure

    Write-Verbose -Message "Finished Test on TestFile"

    return $testResult
}

[DscResource()]
class TestFile
{
    [DscProperty(Key)]
    [String]
    $Path

    [DscProperty()]
    [String]
    $Content

    [DscProperty()]
    [Ensure]
    $Ensure = [Ensure]::Present

    [DscProperty()]
    [Reason[]]
    $Reasons

    [TestFile] Get()
    {
        $getTestFileResult = Get-TestFile -Path $this.Path -Content $this.Content -Ensure $this.Ensure
        return $getTestFileResult
    }

    [void] Set()
    {
        $null = Set-TestFile -Path $this.Path -Content $this.Content -Ensure $this.Ensure
    }

    [bool] Test()
    {
        $testTestFileResult = Test-TestFile -Path $this.Path -Content $this.Content -Ensure $this.Ensure
        return $testTestFileResult
    }
}
