﻿###########################################################
#
#  'DscInstall' module
#
###########################################################

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$script:DscServiceName = "DscService"
$script:DscServiceBinaryName = "dsc_service.exe"
$script:DisplayName = "Guest Configuration Service" 
$script:Description = "This service monitors desired state of the machine."

$script:DscInstallPath = "$PSScriptRoot\..\..\.."
$script:DscBinariesFolderName = "DSC"
$script:UserConfigFolderName = "Configuration"
$script:MigratedDataFolderName = "MigratedData"
$script:PullServiceRegistrationInfoFolderName = "PullServiceRegistrationInfo"
$script:DscBinariesPath = Join-Path $script:DscInstallPath $script:DscBinariesFolderName
$script:MigratedDataPath = Join-Path "$script:DscInstallPath\.." $script:MigratedDataFolderName

<#
    .SYNOPSIS
        Perform Dsc Installation tasks. 
        It Installs Dsc Service and restore dsc state from <DscInstall>\..\MigratedData location.
    
    .Example
        Install-Dsc
#>
Function Install-Dsc {
    [CmdletBinding()]
    Param()

    Write-Verbose -Message "In Install-Dsc" 

    # Restore DSC state from specified directory.
    #
    # TODO: Open issue to look if we need to keep previous state during upgrade. For this release we can go with no state migration.
    #Restore-DscState

    New-Item $(Get-GuestConfigDataPath) -Force -ItemType Directory
    Set-GuestConfigDataPathAcl

    # Install Dsc Service and verify it is installed correctly. 
    InstallAndValidate-DscService
}


 <#
    .SYNOPSIS
        Perform tasks those are required to be Run in Enable handler of Dsc Windows Extension.  
        
    .Example
        Enable-Dsc 
#>
Function Enable-Dsc {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Enable-Dsc"

    # For Full Dsc Since there will be no Enable. We should be able to perform all Enable tasks in Install instead. 
    Start-DscService    
}

<#
    .SYNOPSIS
        Perform Dsc UnInstallation tasks. Currently it just UnInstalls the Dsc Service. 
    
    .Example
        Uninstall-Dsc
#>
Function Uninstall-Dsc {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Uninstall-Dsc"
        
    # Unregister DSC Timer Service
    Uninstall-DscService

    $guestConfigDataPath = Get-GuestConfigDataPath
    Write-Verbose "Removing DSC user data from $guestConfigDataPath path ..."
    if(Test-Path $guestConfigDataPath) {
        Remove-Item $guestConfigDataPath -Recurse -Force
    }
}

<#
    .SYNOPSIS
        Do any state migration during update here.  

    .Example
        Update-Dsc
#>
Function Update-Dsc {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Update-Dsc"
}

 <#
    .SYNOPSIS
        Install Dsc Service. By default it calculates the Dsc Service Binary Path based on this Dsc Install Module location. 
    
    .Example
        InstallAndValidate-DscService
#>
Function InstallAndValidate-DscService {
    [CmdletBinding()]
    Param()   

    Write-Verbose -Message "In Install-Dsc Service"

    if(CheckServiceExists($script:DscServiceName))
    {
        Write-Error "Dsc service already exists, can not install new service"
    }
    else
    {
        $serviceBinaryPath = Join-Path $script:DscBinariesPath $DscServiceBinaryName
        Write-Verbose -Message "Dsc Service binary path : $serviceBinaryPath."

        $serviceApplication = Get-Command -Name $serviceBinaryPath 

        if($serviceApplication.CommandType -ne "Application")
        {
            Write-Error "Service binary type is not as expected" 
        }

        $serviceBinaryPathCommand = $serviceBinaryPath + " -k netsvcs"
  
  
        New-Service -Name $script:DscServiceName -BinaryPathName $serviceBinaryPathCommand -DisplayName $script:DisplayName -Description $script:Description -StartupType Automatic
        
        # For windows 2008 R2 + sp1 start-process with -Wait parameter does not work. Hence sleep for 10 sec instead.
        $osVersion=[Environment]::OSVersion.Version
        if (($osVersion.Major -eq 6) -and ($osVersion.Minor -eq 1) -and ($osVersion.Build -le 7601))
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc -ArgumentList 'failure DscService reset= 30 actions= restart/10000/restart/20000/restart/30000' -PassThru
            Start-Sleep -Seconds 10
        }
        else
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc -ArgumentList 'failure DscService reset=30 actions=restart/10000/restart/20000/restart/30000' -PassThru -Wait
        }
        if ($configureProcess.ExitCode -ne 0)
        {
            Write-Warning "configuring service recovery options failed with exit-code:- $($configureProcess.ExitCode)"
        }
        Write-Verbose -Message "Successfully Installed new Dsc Service."
    }

    Write-Verbose -Message "Validating Dsc Service Properties."
   
    # Validate service Properties as returend by Get-Service.
    $serviceObject = Get-Service -Name $script:DscServiceName
    
    
    if($serviceObject.Status -eq 'Stopped')
    {
        Write-Verbose -Message "Dsc Service is in Stopped State."
    }
    else
    {
        write-error -Message "Dsc Service is in unexpected state: " + $serviceObject.Status;
    }

    if($serviceObject.CanPauseAndContinue -eq $false)
    {
        Write-Verbose -Message "Dsc Service has correct CanPauseAndContinue State."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected CanPauseAndContinue: " + $serviceObject.CanPauseAndContinue;
    }

    if($serviceObject.CanShutdown -eq $false)
    {
        Write-Verbose -Message "Dsc Service has correct CanShutdown State."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected CanShutdown: " + $serviceObject.CanShutdown;
    }
   
    if($serviceObject.CanStop -eq $false)
    {
        Write-Verbose -Message "Dsc Service has correct CanStop State."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected CanStop: " + $serviceObject.CanStop;
    }

    if($serviceObject.ServiceType -eq "Win32OwnProcess")
    {
        Write-Verbose -Message "Dsc Service will run as Win32OwnProcess."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected ServiceType: " + $serviceObject.ServiceType;
    }

    if($serviceObject.StartType -eq "Automatic")
    {
        Write-Verbose -Message "Dsc Service will be started Automatically."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected StartType: " + $serviceObject.StartType;
    }

    # Also validate some service properties from the registry database of scm. 
    $serviceRegistryData = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\DscService

    if($serviceRegistryData.ImagePath -eq $serviceBinaryPathCommand)
    {
        Write-Verbose -Message "Dsc Service Binary is Installed Correctly."
    }
    else
    {
        write-error -Message "Dsc Service binary is not Installed correctly: " + $serviceRegistryData.ImagePath;
    }
    if ($serviceRegistryData.DisplayName -eq $script:DisplayName)
    {
        Write-Verbose -Message "Dsc Service has correct Display Name."
    }
    else
    {
        write-error -Message "Dsc Service has unexpected DisplayName:  " + $serviceRegistryData.DisplayName;
    }
    if($serviceRegistryData.ObjectName -eq "LocalSystem")
    {
        Write-Verbose -Message "Dsc Service will run under LocalSystem Account."
    }
    else
    {
       write-error -Message "Dsc Service has unexpected AccountType: " + $serviceRegistryData.ObjectName;
    }

    if($serviceRegistryData.Description -eq $script:Description)
    {
        Write-Verbose -Message "Dsc Service has correct Description Data. "
    }
    else
    {
        write-error -Message "Dsc Service has unexpected Description: " + $serviceRegistryData.Description 
    }

}

<#
.Synopsis
   Get Guest Config data path.
#>
function Get-GuestConfigDataPath
{
    [CmdletBinding()]
    param ()

    return Join-Path $env:ProgramData 'GuestConfig'
}

<#
.Synopsis
   Acl Guest Config data path.
#>
function Set-GuestConfigDataPathAcl
{
    $guestConfigPath = Get-GuestConfigDataPath
    $acl = Get-Acl $guestConfigPath

    # Removing inherited access rules
    $acl.SetAccessRuleProtection($True, $False)

    # Adding new access rules for the target directory
    $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule('Administrators', 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl $guestConfigPath $acl

    $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule('NT AUTHORITY\SYSTEM', 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl $guestConfigPath $acl
}

<#
    .SYNOPSIS
        Start the Dsc Service. Report Failure if service is not able to start. 

    .Example
       Start-DscService
#>
Function Start-DscService {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Start Dsc Service"
    
    # Start DSC Timer Service, may be retry on failure. 
    Start-Service $script:DscServiceName 

    $serviceObject = Get-Service -Name $script:DscServiceName
    
    if($serviceObject.Status -eq 'Running')
    {
        Write-Verbose -Message "Dsc Service is running."
    }
    else
    {
        Write-Error "Dsc Service can not be started."
    }
}

<#
    .SYNOPSIS
        Stop the Dsc service and then uninstall it.  

    .Example
       Uninstall-DscService
#>
Function Uninstall-DscService {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Uninstall-DscService"
        
    # Unregister DSC Timer Service
    
    $timeOut = [timespan]::FromMinutes(5)
    $stopRetry = [DateTime]::Now.Add($timeOut)
    $secondsBetweenRetry = 3
    Stop-Service $script:DscServiceName -ErrorAction SilentlyContinue -ErrorVariable stopTimeError
    while(((Get-Service -Name $script:DscServiceName).Status -ne 'Stopped') -and ([dateTime]::Now -le $stopRetry))
    {
          Write-Verbose "Wait for service to stop" -Verbose
          sleep -Seconds $secondsBetweenRetry
    }
    
    $serviceObject = Get-Service -Name $script:DscServiceName
    
    if($serviceObject.Status -eq 'Stopped')
    {
        Write-Verbose -Message "Dsc Service is stopped."
        sc.exe delete $script:DscServiceName
    }
    else
    {
        Write-Error "Dsc Service can not be Uninstalled because we are not able to stop it."
    }

    # some basic validation to check service is Uninstalled. 
    $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\DscService -ErrorAction SilentlyContinue

    If ($serviceRegistryExists -ne $null) {

        # some times the registry clean up does not happen right away. Hence do retry for the check.
        while(($serviceRegistryExists -ne $null) -and ([dateTime]::Now -le $stopRetry))
        {
            sleep -Seconds $secondsBetweenRetry
            $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\DscService -ErrorAction SilentlyContinue
        }

        # if service registry entry still exist.
        If ($serviceRegistryExists -ne $null)
        {
            Write-Error "Dsc Service is not Uninstalled correctly. Information is Present in Registry Database."
        }
    }

    $getService = Get-Service $script:DscServiceName -ErrorAction SilentlyContinue
    
    If ($getService -ne $null) {
          Write-Error "Dsc Service is not Uninstalled correctly. Service is reporting status."
    }
}

Function CheckServiceExists($serviceName)
{   
    if (Get-Service $serviceName -ErrorAction SilentlyContinue)
    {
        return $true
    }
    return $false
}

Function Restore-DscState
{
    [CmdletBinding()]
    Param()

    $srcPath = $script:MigratedDataPath
    if(-not (Test-Path $srcPath)) {
        return
    }

    # Restore Dsc State data
    $srcConfigPath = Join-Path $srcPath $script:UserConfigFolderName
    $destConfigPath = Join-Path $script:DscInstallPath $script:UserConfigFolderName
    New-Item -ItemType Directory -Path $destConfigPath -Force
    if(Test-Path $srcConfigPath) {
        Copy-Item "$srcConfigPath\\*.mof" $destConfigPath -Force
        Copy-Item "$srcConfigPath\\*.checksum" $destConfigPath -Force
    }

    # Restore Dsc Registration data
    $srcRegistrationPath = Join-Path $srcPath $script:PullServiceRegistrationInfoFolderName
    $destRegistrationPath = Join-Path $script:DscBinariesPath $script:PullServiceRegistrationInfoFolderName
    New-Item -ItemType Directory -Path $destRegistrationPath -Force
    if(Test-Path $srcRegistrationPath) {
        Copy-Item "$srcRegistrationPath\\*.*" $destRegistrationPath -Force
    }

    # Clean migration data folder.
    Remove-Item -Recurse -Force $srcPath
}

Export-ModuleMember -Function @(
    'Install-Dsc',
    'Enable-Dsc',
    'Uninstall-Dsc',
    'Update-Dsc'
    )
