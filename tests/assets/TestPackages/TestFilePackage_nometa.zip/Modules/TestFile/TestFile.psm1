class Reason
{
    [DscProperty()]
    [String] $Code

    [DscProperty()]
    [String] $Phrase
}

function Get-TestFile
{
    [CmdletBinding()]
    [OutputType([TestFile])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content
    )

    Write-Verbose -Message "Starting Get on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content"

    $testFileContent = $null
    $reasons = [Reason[]]@()

    Write-Verbose -Message "Retrieving test file from the path '$Path'"
    $testFileExists = Test-Path -Path $Path

    if ($testFileExists)
    {
        $testFileContent = Get-Content -Path $Path -Raw

        if ($testFileContent -ne $Content)
        {
            $reason = [Reason]::new()
            $reason.Code   = 'TestFile:TestFile:FileContentMismatch'
            $reason.Phrase = "The file content was expected to be: '$Content' but the actual file content is: '$testFileContent'"
            $reasons += $reason
        }
    }
    else
    {
        $reason = [Reason]::new()
        $reason.Code   = 'TestFile:TestFile:FileNotExists'
        $reason.Phrase = "The file does not exist when it was expected to exist at the path '$Path'"
        $reasons += $reason
    }

    if ($reasons.Count -eq 0)
    {
        $reason = [Reason]::new()
        $reason.Code   = 'TestFile:TestFile:Compliant'
        $reason.Phrase = "The file at the '$Path' is compliant."
        $reasons += $reason
    }

    $result = [TestFile]::new()
    $result.Path = $Path
    $result.Content = $testFileContent
    $result.Reasons = $reasons

    Write-Verbose -Message "Finished Get on TestFile"

    return $result
}

function Set-TestFile
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content
    )

    Write-Verbose -Message "Starting Set on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content"

    # Remove-Item $path -Force -ErrorAction SilentlyContinue
    $null = Set-Content -Path $Path -Value $Content -NoNewline -Force

    Write-Verbose -Message "Finished Set on TestFile"
}

function Test-TestFile
{
    [CmdletBinding()]
    [OutputType([bool])]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Path,

        [Parameter()]
        [String]
        $Content
    )

    Write-Verbose -Message "Starting Test on TestFile"

    $Path = $ExecutionContext.InvokeCommand.ExpandString($Path)

    Write-Verbose -Message "Parameters`n`tPath:$Path`n`tContent:$Content"

    $getTestFileResult = Get-TestFile @PSBoundParameters

    Write-Verbose -Message "Retrieved resource properties`n`tPath:$($getTestFileResult.Path)`n`tContent:$($getTestFileResult.Content)"
    $testResult = ($getTestFileResult.Path -eq $Path) -and ($getTestFileResult.Content -eq $Content)

    Write-Verbose -Message "Finished Test on TestFile"

    return $testResult
}

[DscResource()]
class TestFile
{
    [DscProperty(Key)]
    [String]
    $Path

    [DscProperty()]
    [String]
    $Content

    [DscProperty(NotConfigurable)]
    [Reason[]]
    $Reasons

    [TestFile] Get()
    {
        $getTestFileResult = Get-TestFile -Path $this.Path -Content $this.Content
        return $getTestFileResult
    }

    [void] Set()
    {
        $null = Set-TestFile -Path $this.Path -Content $this.Content
    }

    [bool] Test()
    {
        $testTestFileResult = Test-TestFile -Path $this.Path -Content $this.Content
        return $testTestFileResult
    }
}
